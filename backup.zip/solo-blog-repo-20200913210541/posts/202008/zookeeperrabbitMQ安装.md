title: zookeeper\rabbitMQ安装
date: '2020-08-05 10:51:12'
updated: '2020-08-05 10:51:12'
tags: [随笔记录, 编译工具]
permalink: /articles/2020/08/05/1596595872827.html
---
起因：

前段时间学习了redis，然后搭建了redis集群，然后昨天开始安装zookeeper和rabbitMQ集群.

tmd醉了，两个环境装了一天多，一直在踩坑。为什么呢？建议大家还是别是用docker安装zookeeper集群了，因为你会遇到无数的问题，我就是一直被docker折腾着。好了记录一下，下次安装用：

docker安装rebbit集群：

```
docker pull rabbitmq:3.6.15-management

rabbitMQ：
---------------
单机：
docker run -d --name rabbitmq3.8 -p 5672:5672 -p 15672:15672 -v /dockerData/rabbitMQ:/var/lib/rabbitmq --hostname myRabbit -e RABBITMQ_DEFAULT_VHOST=my_vhost 

集群：
docker run -d --hostname rabbit1 --name rabbitmq1 -p 15672:15672 -p 5672:5672 -v /dockerData/rabbitmq:/var/lib/rabbitmq -e RABBITMQ_ERLANG_COOKIE='rabbitmqcookie' -e RABBITMQ_DEFAULT_USER=admin -e RABBITMQ_DEFAULT_PASS=18314263373 --restart always f2e38e79371c
docker run -d --hostname rabbit2 --name rabbitmq2 -p 5673:5672 -v /dockerData/rabbitmq:/var/lib/rabbitmq --link rabbitmq1:rabbit_host1 -e RABBITMQ_ERLANG_COOKIE='rabbitmqcookie' -e RABBITMQ_DEFAULT_USER=admin -e RABBITMQ_DEFAULT_PASS=18314263373 --restart always f2e38e79371c
docker run -d --hostname rabbit3 --name rabbitmq3 -p 5674:5672 -v /dockerData/rabbitmq:/var/lib/rabbitmq --link rabbitmq1:rabbit_host1 --link rabbitmq2:rabbit_host2 -e RABBITMQ_ERLANG_COOKIE='rabbitmqcookie' -e RABBITMQ_DEFAULT_USER=admin -e RABBITMQ_DEFAULT_PASS=18314263373 --restart always f2e38e79371c

节点1
docker exec -it rabbitmq1 bash
rabbitmqctl stop_app
rabbitmqctl reset
rabbitmqctl start_app
exit

节点2
docker exec -it rabbitmq2 bash
rabbitmqctl stop_app
rabbitmqctl reset
rabbitmqctl join_cluster --ram rabbit@rabbit1
rabbitmqctl start_app
exit

节点3
docker exec -it rabbitmq3 bash
rabbitmqctl stop_app
rabbitmqctl reset
rabbitmqctl join_cluster --ram rabbit@rabbit1
rabbitmqctl start_app
exit
```


centOS安装zookeeper

```
安装java
yum -y install java-1.8.0-openjdk.x86_64

1. 下载zookeeper上传||在线下载
2. 解压：
tar -zxvf apache-zookeeper-3.6.1-bin.tar.gz
3. 在data中建立server1 、server2、server3
4. 将apache-zookeeper-3.6.1-bin内容拷贝到server1、2、3中
  cp -r apache-zookeeper-3.6.1-bin/ server1/
5. 在每个server中创建data
6. 创建myid文件 （依次写入1、2、3）
7. 进入conf文件夹，复制 zoo_simple.cfg
   cp zoo.simple.cfg zoo.cfg
8. 依次修改zoo.cfg
   内容为：

tickTime=2000
initLimit=10
syncLimit=5
dataDir=/dockerData/zookeeper/server1/data
clientPort=2181  #每个server需要不同port

server.1=127.0.0.1:2888:3888
server.2=127.0.0.1:2889:3889
server.3=127.0.0.1:2890:3890

9. 进入：zookeeper/server2/bin文件夹
执行命令./zkServer.sh start

```
