title: 读写excel表格
date: '2020-10-29 16:19:34'
updated: '2020-10-29 22:26:10'
tags: [待分类, 随笔记录]
permalink: /articles/2020/10/29/1603959574713.html
---
excel读写xls文件

依赖：

```pom
 <!-- https://mvnrepository.com/artifact/net.sourceforge.jexcelapi/jxl -->
        <dependency>
            <groupId>net.sourceforge.jexcelapi</groupId>
            <artifactId>jxl</artifactId>
            <version>2.6.12</version>
        </dependency>
```

java文件

```java
import java.io.*;
import java.util.ArrayList;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;


/**
 * @author wsl
 */
public class maintest {
    public static void main(String[] args) {
        try {
            //获取指定行的值
            ArrayList<ArrayList<String>> arr2 = readSpecifyRows(new File("C:\\Users\\wsl\\Desktop\\test.xls"));
            ArrayList<ArrayList<String>> arr1 = readSpecifyRows(new File("C:\\Users\\wsl\\Desktop\\test1.xls"));

            arr1.forEach(li ->{
                arr2.forEach(tt ->{
                    if (li.get(2).equals(tt.get(2))&&!li.get(0).equals(tt.get(0))&&li.get(4).equals(tt.get(4))){
                        System.out.println("name:"+li.get(2)+"\tid1"+li.get(0)+"\tid2:"+tt.get(0));
                    }
                });
            });

            write();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     *   	读取指定行
     * @param file
     * @throws Exception
     */
    public static  ArrayList<ArrayList<String>> readSpecifyRows(File file)throws Exception{

        Workbook readwb;
        InputStream io = new FileInputStream(file.getAbsoluteFile());
        readwb = Workbook.getWorkbook(io);
        Sheet readsheet = readwb.getSheet(0);
        int rsColumns = readsheet.getColumns();

        int rsRows = readsheet.getRows();

        ArrayList<ArrayList<String>> arr = new ArrayList<>();
        for (int i = 0; i < rsRows;i++){
            ArrayList<String> columnList = new ArrayList<>();
            for (int j = 0; j < rsColumns; j++) {
                Cell cell_name = readsheet.getCell(j, i);
                columnList.add(cell_name.getContents());
            }
            arr.add(columnList);
        }

        return arr;
    }
    /**
     * JXL 创建Excel文件
     * @author yangtingting
     * @date 2019/07/29
     */
    public static void write() throws Exception{
        //创建Excel文件
        File file=new File("/jxl_test.xls");
        //创建文件
        file.createNewFile();
        //创建工作薄
        WritableWorkbook workbook = Workbook.createWorkbook(file);
        //创建sheet
        WritableSheet sheet=workbook.createSheet("sheet1",0);
        //添加数据
        String[] title={"id","name","sex"};
        Label label=null;
        for (int i=0;i<title.length;i++){
            label=new Label(i,0,title[i]);
            sheet.addCell(label);
        }
        //追加数据
        for (int i=1;i<10;i++){
            label=new Label(0,i,"a"+1);
            sheet.addCell(label);
            label=new Label(1,i,"user"+1);
            sheet.addCell(label);
            label=new Label(2,i,"男"+1);
            sheet.addCell(label);
        }
        workbook.write();
        workbook.close();

    }
}
```
