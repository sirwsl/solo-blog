title: ' Java开发常用注解'
date: '2020-05-23 23:55:15'
updated: '2020-05-24 00:26:57'
tags: [java, spring, springboot, mybatis]
permalink: /articles/2020/05/23/1590249315247.html
---
![](https://b3logfile.com/bing/20171227.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


### 一、java注解

| 注释 | 作用 |  
| --- | --- | 
| @Override | 覆盖父类方法 |   
| @interface | @interface MyTest{}自定义注解 |   
| @Inherited | 标注与父类，子类继承父类注解 |   

### 二：Lombok：

依赖：

```
<!-- https://mvnrepository.com/artifact/org.projectlombok/lombok -->
<dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
    <version>1.18.10</version>
    <scope>provided</scope>
</dependency>

```

优点：

1. 精华代码，通过注解实现，@Data可以简单定义一个java Bean
2. @ToString、@EqualsAndHashCode、@Getter、@Setter等注解省去大量的get、set、toString，提高效率，代码更加简洁
3. 总之就是使用之后代码更加简洁，对于实体类只需要定义属性，不需要编写大量get、set、toString

缺点：

1. 需要安装对应依赖，项目中一个人使用，大家都得使用
2. 代码可读性降低，在编写阶段，调试容易带来一定问题
3. 使用需要阅读底层原理，避免出现bug，eg：当我们使用@Data注解时候调用equals时如果没使用@EqualsAndHashCode(callSuper=true)就会出现只比较子类属性，不会比较父类继承属性
4. 默认注解方法全部为public，安全性、封装性降低

| 注解 | 使用 | 说明 |
| --- | --- | --- |
| @Data | 类 | 会自动生成get、set、equal、同String、hashCode等相关方法 |
| @Getter | 属性 | 生成对应属性的getter方法 |
| @Setter | 属性 | 生成对应属性的setter |
| @NonNull | 属性、构造器 | 非空声明、避免空指针 |
| @Cleanup | 局部变量 | 自动调用close()方法（eg:文件流读取） |
| @EqualsAndHashCode | 类 | 默认使用所有属性来生成equals和hasCode，也能通过exclude注解来排除一些属性 |
| @ToString | 类 | 生成对应tostring方法 |
| @NoArgsConstructor, | 类 | 无参构造器 |
| @RequiredArgsConstructor | 类 | 部分参数构造器 |
| @AllArgsConstructor | 类 | 全部参数构造器### |

依赖：

```
<!-- https://mvnrepository.com/artifact/org.mybatis/mybatis -->
<dependency>
    <groupId>org.mybatis</groupId>
    <artifactId>mybatis</artifactId>
    <version>3.4.6</version>
</dependency>

```

### 三、mybatis

mybatis最初配置信息是基于 XML ,SQL定义在 XML 中的。而MyBatis 3提供了新的基于注解的配置

| 注解 | 说明 |   
| --- | --- | 
| @select | 查询 |   
| @results | 数据库表与bean字段的映射关系 |   
| @update | 更新 |   
| @insert | 新增 |   
| @delete | 删除 |   
| @ResultMap | 设置返回类型映射 |   
| @MapKey | 查询数据转化为Map<> |   
| @Param | 重命名参数 |   

PS：# and $ 区别

#{}采用预编译处理，之后通过参数替换?可以有效防止SQL注入问题

${}采用直接赋值，未经过预编译处理，非安全，存在SQL注入

### 四、Spring系列

1、

| 注解 | 说明 |   
| --- | --- | 
| @Controller | 标注控制层组件 |   
| @Service | 标注业务层组件 |   
| @Bean | 标注作为Spring中的bean |   
| @Scope | 作用域 |   
| @Autowired | 按类型装配注入 |   
| @Required | bean的setter方法，属性必须在xml文件填充否则抛出异常 |   |
| @Qualifier | 指明哪个bean被真正装配 |   
| @ResponseBody | 接收前端数据 |   
| @RestController | 标识控制层组件，传递数据为json类型，@ResponseBody和@Controller |   
| @RequestMapping | 处理请求地址映射注解 |   
| @GetMapping | 表明是一个查询URL映射 |   
| @PutMapping | 表明是一个更新URL映射 |   
| @PostMapping | 表明是一个怎加URL映射 |   
| @DeleteMapping | 表明是一个删除URL映射 |   
| @Async | 用于异步方法调用 |   
| @EnableAutoConfiguration | 自动配置 |   
| @ComponentScan | 组件扫描，自动发现装配bean |   
| @Value | 配置属性值 |   
| @Pathvariable | 获取路径变量 |   
| @ExceptionHandler(Exception.class) | 标注方法上统一的异常处理 |   
| @DateTimeFormat | 时间格式刷 |   


2. Entity实体类：

| 注解 | 说明 | 
| --- | --- | 
| @DynamicUpdate | 发生更新时，只更新改变字段 |   
| @Dynamiclnsert | 字段为空则不执行插入 |   
| @Id | 标记主键 |   
| @Entity | 与数据进行映射的实体类 |   
| @CeneratedValue | 自增属性 |   
| @JsonProperty | 序列化为注解中的名称 |   

❤️ 遇到新的持续更新中❤️
