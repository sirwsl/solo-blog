title: docker + Linux部分常用命令
date: '2020-06-07 11:01:47'
updated: '2020-06-07 11:02:44'
tags: [docker, Linux]
permalink: /articles/2020/06/07/1591498907666.html
---
前言：

好久没有写博客了，因为前段时间既用友之后又收到了百盛的远程实习offer然后上了两天班，觉得那些东西并不是我想要的（待遇各种还不错，但是技术比较老），然后决定还是好好学习，在补充一下自己的知识技能，然后决定秋招再站。希望秋招有厂收了我。我这个人吧老是闲不下来，昨天一无聊，准备在原有已经运行的solo上在挂载点东西，然后折腾一番，现在写一下常用命令，防止下次运行时候忘记还可以再看看。废话不多说，干就完事了。

❤️ 正式开始❤️ 

### 一、docker常用命令：

docker 重启命令

```
systemctl restart docker
```

查看docker中正在运行的容器：

```
docker ps
```

查看docker中未运行的容器：

```
docker ps -a
```

删除docker中的某个容器：

```
docker rm + container id
```

删除docker中的某个镜像：

```
docker rmi +image id
```

docker中 启动所有的容器命令

```
docker start $(docker ps -a | awk '{ print $1}' | tail -n +2)
```

docker中   关闭所有的容器命令

```
docker stop $(docker ps -a | awk '{ print $1}' | tail -n +2)
```

docker中 删除所有的容器命令

```
docker rm $(docker ps -a | awk '{ print $1}' | tail -n +2)
```

docker中   删除所有的镜像

```
docker rmi $(docker images | awk '{print $3}' |tail -n +2
```

docker中停止容器：

```
docker stop +container Id
```

当容器存在时启动：

```
docker start +container Id
```

docker启动容器：

```
docker run -d --name demo -p 888:888 my/demo
```



### **二、linux常用命令：**

删除文件夹或文件

```
rm -rf +文件夹/文件
```

创建文件夹

```
markdir +名称
```

查看列表：

```
ls
```

查看进程：

```
ps
```

```
ps -a -l  终端机所有进程信息   —A 所有进程
```

杀死进程：

```
kill +pid    杀死进程
kill -9 +pid  彻底杀死进程
kill -KILL 123456  强制杀死进程
```

远程：

```
mac：ssh root@127.1.1.1
```

文件上传：

```
mac：scp +文件路径+root@ip:文件夹路径
eg:scp /Users/wsl/demo.jar root@127.0.0.1:/var/myself
```

Xshell:

```
rz -y
```

如果没有这个命令运行：

```
 yum   -y  install  lrzs
```
