title: solo更新
date: '2020-07-08 14:54:38'
updated: '2020-07-08 14:54:38'
tags: [随笔记录]
permalink: /articles/2020/07/08/1594191278868.html
---
开始想弄脚本，后面想想算了，这个也省事，solo也没有那么快的更新

写一下，省的下次手动去找。

手动更新solo

```
docker stop solo  #停止solo
docker rm solo  #删除solo镜像
docker pull b3log/solo:latest #拉取最新镜像

```

重新部署：

```
docker run --detach --name solo --network=host \
--env RUNTIME_DB="MYSQL" \
--env JDBC_USERNAME="root" \
--env JDBC_PASSWORD="" \
--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
b3log/solo --listen_port=8080 --server_scheme=https --server_host=www.wslhome.top --server_port=
```



PS：docker启动nginx

```
nginx:
（8080(port)->80）
docker run -d -p 80:8080 -p 443:443 --name nginx -v /dockerData/nginx/conf/nginx.conf:/etc/nginx/nginx.conf -v /dockerData/nginx/conf/conf.d:/etc/nginx/conf.d -v /dockerData/nginx/ssl:/ssl/ -v /dockerData/nginx/www:/usr/share/nginx/html -v /dockerData/nginx/logs:/var/log/nginx nginx

```
