title: 设计模式:Factory method(工厂模式)--创建型模式
date: '2020-06-10 19:40:58'
updated: '2020-06-10 19:46:56'
tags: [设计模式]
permalink: /articles/2020/06/10/1591789258840.html
---
![](https://b3logfile.com/bing/20181209.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 一、介绍

定义一个创建对象的接口，让子类决定实例化哪一个类。Factory Method使得要给类的实例化延迟到子类

同时封装类中善变的部分，提取其中多变部分为独立的类

### 二、适用性

当一个类不知道它所必须创建的对象的类的时候

当一个类希望他的子类来指定它所创建对象的时候

当类将创建对象的职责委托给多个帮助子类中的一个，并且你希望将哪一个帮助子类是代理者这一信息局部化的时候

### 三、参与者

**Product**

定义工厂方法所创建的对象接口

**ConcreteProduct**

实现Product接口

**Creator**

声明工厂方法返回一个product类型的对象。

**ConcteteCreator**

重新定义工厂方法，返回一个COncreateProduct实例

### 四、效果

* 为子类提供钩子（hook）

在工厂方法中一个类的内部创建对象通常比直接创建对象更加灵活

* 连接平行的类层次

工厂方法并不只是被Creator调用，客户可以找到一些有用的工厂方法，尤其是在平行的类层次下（平行类层次：当一个类的一些职责委托给一个独立的类的时候）

### 五、实现

Creator依赖于他的子类来定义工厂方法，所以它放回一个适当的ConcreatProduct实例

**1.场景**

当我们去买泡面的时候就有许多的选择：红烧牛肉面、清水面、排骨面等等，这些泡面有共性也有不同。而我们只是关注我要买的泡面是什么。所以我们定义工厂接口（Creator）来获取泡面对象（Product），而每个泡面都有共同点我们作为（父类），用子类继承不同的部分。然后通过重新定义工厂方法（ConcreteCreator）来获得不同的泡面。

**2.UML建模**

![QQ截图20200610102440.png](https://b3logfile.com/file/2020/06/QQ截图20200610102440-a92d66d4.png)

**3.编码**
创建一个product

![image.png](https://b3logfile.com/file/2020/06/image-3a109e60.png)

子类实现其不同的type（）

![image.png](https://b3logfile.com/file/2020/06/image-c2311066.png)![image.png](https://b3logfile.com/file/2020/06/image-5d70baa8.png)

**4.创建一个Creator抽象工厂**

![image.png](https://b3logfile.com/file/2020/06/image-c9be5b90.png)

**5.ConcteteCreator重新定义工厂方法**

![image.png](https://b3logfile.com/file/2020/06/image-48dc2eca.png)![image.png](https://b3logfile.com/file/2020/06/image-8145a9a1.png)

**6.测试用例**

![image.png](https://b3logfile.com/file/2020/06/image-734714c2.png)结果：

![image.png](https://b3logfile.com/file/2020/06/image-1f9fcd4a.png)

#### 4. 源码：[参见我的github中DesignPatten](https://github.com/sirwsl/DesignPatten)

* [https://github.com/sirwsl/DesignPatten](https://github.com/sirwsl/DesignPatten)
