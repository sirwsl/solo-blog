title: 设计模式:Builder(生成器)--创建型模式
date: '2020-06-10 18:07:02'
updated: '2020-06-10 18:10:32'
tags: [设计模式]
permalink: /articles/2020/06/10/1591783622594.html
---
![](https://b3logfile.com/bing/20181020.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 一、介绍：

**将一个复杂对象的构建与它的表示相分离，使得同样的构建过程可以创建不同的表示。**

就是我们在创建一系列复杂对象的时候，我们将其过程抽象出来，而每个抽象的部分有不同的实现方式，因此我们在创建对象时，不同的实现方式就导致了创建对象的不同

### 二、适用性

* 当创建复杂对象的算法应该独立于该对象的组成部分以及他们的装配方式时。
* 当构造过程必须允许被构造的对象有不同的表示时

### 三、参与者

**Builder**

创建一个product对象的各个部件的制定抽象接口。

**ConcreateBuilder**

实现Builder接口以构造和装配产品各个部件

定义和跟踪它所创建的表示

提供一个检索产品的接口

**Director**

构造一个使用Builder接口的对象

**Product**

被构造的复杂对象。包括定义组件的类与这些部件装配的产品接口

### 四、效果

* 可以改变一个产品得到内部表示。

Builder对象提供一个构造产品的抽象接口，该接口隐藏了这个产品的表示和内部结构与如何装配。

* 将构造代码与表示代码分开

Builder通过封装一个复杂对象的创建与表示提供了对象的模块性。而使用者直接出接口，而不需要知道内部结构类信息。每个ConcreteBuilder包含了创建于装配一个特定产品的代码。这些代码只需要写一次，由Director进行复用，使用在相同部件的基础上构建不同的产品

* 实现对构造过程更加精细的控制

Builder模式下可实现对产品一步步的构造，只有当产品完成时才返回对象。英雌Builder接口比其他创建型模式更好的反应产品的构造过程，这使得它可以更加精确的控制构建过程。

### 五、实现

**1.场景**

当我们在购买电脑时候就需要考虑内存、cpu、主板、外观等等因素。当你说出需求后老板会寻找对应的部件给你组装。因此我们抽象这些安装步骤出来。

换句话说就是，我们抽象所有的安装步骤为一个接口（Builder）然后通过ConcreteBuilder实现具体的步骤（选择什么CPU、主板、内存等等）。然后老板（Director）将电脑组装后返回给你一台电脑（Product）

**2.UML建模**

![QQ截图20200609193244.png](https://b3logfile.com/file/2020/06/QQ截图20200609193244-20c21535.png)

**3.编码**：
**(1)创建一个product（computer）**

![image009ee235.png](https://b3logfile.com/file/2020/06/image009ee235-1f574b52.png)

**(2)创建各个步骤的抽象接口**

![image.png](https://b3logfile.com/file/2020/06/image-177b623e.png)

**(3)创建各个部分的接口的实现类**

![image.png](https://b3logfile.com/file/2020/06/image-e73a91f4.png)

**(4)对接口的使用（老板开始组装电脑）**

![image.png](https://b3logfile.com/file/2020/06/image-e4ffb9f3.png)

**(5)测试用例**

结果:![image.png](https://b3logfile.com/file/2020/06/image-4e07c23c.png)

#### 4. 源码：[参见我的github中DesignPatten](https://github.com/sirwsl/DesignPatten)

* [https://github.com/sirwsl/DesignPatten](https://github.com/sirwsl/DesignPatten)




Okhttp中的Request对象使用的Builder设计模式分析参见大佬博客
https://www.jianshu.com/p/f958ba891467

@Builder使用参见博客

https://www.jianshu.com/p/5e42ecede166
