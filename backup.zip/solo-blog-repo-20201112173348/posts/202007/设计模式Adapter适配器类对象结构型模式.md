title: 设计模式:Adapter(适配器)--类对象结构型模式
date: '2020-07-29 17:57:58'
updated: '2020-07-29 17:57:58'
tags: [设计模式]
permalink: /articles/2020/07/29/1596016678167.html
---
![](https://b3logfile.com/bing/20190327.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 一、介绍

Adapter（适配器）也叫做包装器(wrapp)。在许多时候横夺得类不能够被复用，仅仅是因为将一个类的接口与专业应用得接口不匹配。当一些类的接口互不兼容，这时候就需要适配器。它能**将一个类的接口转化为客户希望的另一个接口。Adapter模式使得由于接口不兼容不能在一起工作得那些类可以在一起工作。**

* **优点：
  1.类的透明性
  2.类的复用度
  3.灵活性
  4.可以让任何两个没有关联的类一起运行**
* **PS:
  项目一定要遵守依赖倒置原则和里氏替换原则，否则即使在适合使用适配器的场合下，也会带来非常大的改造**

### 二、适用性

* 当你想使用一个已经存在的类，但他的接口不符合你的需求
* 当你想创建一个可以复用的类，该类可以与其他不相关的类或不可遇见的类（接口可能不一定兼容的类）一起协同工作
* 你想使用一些已经存在的子类，但是不可能对每一个都进行子类化以匹配他们的接口。对象适配器可以适配他的父类接口。

### 三、参与者

![扫描全能王2020072917.23.16.jpg](https://b3logfile.com/file/2020/07/扫描全能王2020072917.23.16-20b6d054.jpg)

* **Target**
  定义Client使用的与特定邻域相关的接口
* **Client**
  与符合Target接口的对象协同
* **Adaptee**
  定义一个已经存在的接口，这个接口需要适配
* **Adapter**
  对Adaptee的接口与Target接口进行适配

### 四、效果

#### 类适配器

* 用一个具体的Adapter类对Adaptree和Target进行匹配。结果是当我们想要匹配一个类以及他的子类的时候，类Adapter不能够胜任工作
* 使得Adapter可以重新定义adaptee的部分行为，因为Adapter是Adaptee的一个子类
* 仅仅引入一个对象，并不需要二外的指针间接得到Adaptee

#### 对象适配器

* 允许一个Adapter与多个Adaptee--Adaptee本身以及他的所有子类同时工作。Adapter可以一次给所有的Adaptee添加功能
* 使得重新定义Adaptee的行为比较困难，这就需要生成Adaptee的子类并且使得Adapter引用这个子类而不是应用Adaptee

### 五、实现

我们现在来看一个例子：

当我们在读书的时候都知道，有本校学生，还有寄读学生（学籍不再所就读学校）。我们想想这样一个场景。有一所高中的学生信息管理系统，由由于之前一直都是本校的学生就读，没有寄读学生。但是后来来了一部分寄读学生，这时候寄读学生信息需要从原来学校接口获取。但是寄读学生的学籍所在高校只提供Map接口，这时候是不是就陷入难题，于是就出现了适配器。

* **UML：**

![QQ截图20200729163204.png](https://b3logfile.com/file/2020/07/QQ%E6%88%AA%E5%9B%BE20200729163204-16f26a29.png)

* **代码：**

StudedntInfo接口：本校学生信息管理接口

```java
public interface StudentInfo {

    String getName();

    String getAge();

    String getAdress();

    String getIDCard();

    String getMaName();

    String getFaName();

    String getMaPhone();

    String getFaPhone();
}
```

studentImp类：实现studentInfo接口

```java
public class StudentImp implements StudentInfo{

    @Override
    public String getName() {
        System.out.println("测试学生姓名");
        return null;
    }

    @Override
    public String getAge() {
        System.out.println("测试学生年龄");
        return null;
    }

    @Override
    public String getAdress() {
        System.out.println("测试学生家庭住址");
        return null;
    }


    @Override
    public String getIDCard() {
        System.out.println("测试学生身份证号");
        return null;
    }

    @Override
    public String getMaName() {
        System.out.println("测试学生母亲姓名");
        return null;
    }

    @Override
    public String getFaName() {
        System.out.println("测试学生母亲电话");
        return null;
    }

    @Override
    public String getMaPhone() {
        System.out.println("测试学生父亲姓名");
        return null;
    }

    @Override
    public String getFaPhone() {
        System.out.println("测试学生父亲电话");
        return null;
    }
}
```

接口OutStudentInfo：寄读学生接口（Map类型）

```java
public interface OutStudentInfo {
    //学生个人信息
    Map selfInfo();

    //学生家长信息
    Map parentInfo();
}
```

OutStudentImp：寄读学生实现类，实现OutStudentInfo接口

```java
public class OutStudentImp implements OutStudentInfo{
    @Override
    public Map selfInfo() {
        Map student = new HashMap();
        student.put("name","测试寄读学生姓名");
        student.put("age","测试寄读学生年龄");
        student.put("sex","测试寄读学生性别");
        student.put("adress","测试寄读学生家庭住址");
        student.put("ID","测试寄读学生身份证号");

        return student;
    }

    @Override
    public Map parentInfo() {
        Map parent = new HashMap();
        parent.put("maName","测试寄读学生母亲姓名");
        parent.put("maPhone","测试寄读学生母亲电话");
        parent.put("faName","测试寄读学生父亲姓名");
        parent.put("faPhone","测试寄读学生父亲电话");
        return parent;
    }
}
```

Adapter适配器:继承OutStudentImp寄读学生实现类，实现StudentInfo接口

```java
public class Adapter extends OutStudentImp implements StudentInfo{

    private Map student =super.selfInfo();
    private Map parent = super.parentInfo();

    @Override
    public String getName() {
        String name = (String) this.student.get("name");
        System.out.println(name);
        return name;
    }

    @Override
    public String getAge() {
        String age = (String) this.student.get("age");
        System.out.println(age);
        return age;
    }

    @Override
    public String getAdress() {
        String adress = (String) this.student.get("adress");
        System.out.println(adress);
        return adress;
    }

    @Override
    public String getIDCard() {
        String ID = (String) this.student.get("ID");
        System.out.println(ID);
        return ID;
    }

    @Override
    public String getMaName() {
        String name = (String) this.parent.get("maName");
        System.out.println(name);
        return name;
    }

    @Override
    public String getFaName() {
        String name = (String) this.parent.get("faName");
        System.out.println(name);
        return name;
    }

    @Override
    public String getMaPhone() {
        String phone = (String) this.parent.get("maPhone");
        System.out.println(phone);

        return phone;
    }

    @Override
    public String getFaPhone() {
        String phone = (String) this.parent.get("faPhone");
        System.out.println(phone);
        return phone;
    }
}
```

测试：

```java
public class Main {
    public static void main (String[] args){
        StudentInfo student1 = new StudentImp();
        StudentInfo student2 = new Adapter();
        student1.getName();
        student1.getAdress();
        student1.getAge();
        student1.getIDCard();
        student1.getMaName();
        student1.getMaPhone();
        student1.getFaName();
        student1.getFaPhone();
        System.out.println("-------------------");
        student2.getName();
        student2.getAdress();
        student2.getAge();
        student2.getIDCard();
        student2.getMaName();
        student2.getMaPhone();
        student2.getFaName();
        student2.getFaPhone();

    }
}
```
