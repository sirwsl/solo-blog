title: map循环、迭代器
date: '2020-10-28 00:06:18'
updated: '2020-10-28 00:06:18'
tags: [JAVA]
permalink: /articles/2020/10/28/1603814778834.html
---
## 故事

现在是11：47pm，刚刚和女朋友还有老爸打完电话，然后8点左右下班的，自己看了会抖音，还是把这玩意写写吧，故事是这样的，今天上班时候用到map的遍历，然后遇到一个棘手的问题就是，如何改变map中key的值而不改变value的值，想到刚刚，还是没有能够想明白怎么做，然后还是之前的方案，先新建一个map，然后在获取值然后在复制吧，大概目前以我的能力好像只能这样了，然后无聊有看了看map的遍历大概如下

```java
package com.example.demo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

//@SpringBootTest
class DemoApplicationTests {

    @Test
    public void hashMapTest(){
        Map<String,User> userMap = new HashMap<>();
        userMap.put("test1",new User("1","sirWsl1"));
        userMap.put("test2",new User("2","sirWsl2"));
        userMap.put("test3",new User("3","sirWsl3"));
        userMap.put("test4",new User("4","sirWsl4"));
        userMap.put("test5",new User("5","sirWsl5"));
        userMap.put("test6",new User("6","sirWsl6"));
        userMap.put("test7",new User("7","sirWsl7"));

        //for循环遍历
        for(String key : userMap.keySet()){
            System.out.println("keys:"+key+"\tvalue:"+userMap.get(key).toString());
        }

        // for取值
        for(User user:userMap.values()){
            System.out.println("values:"+user.toString());
        }

        // for循环 可以获取key与value
        for (Map.Entry<String, User> stringUserEntry : userMap.entrySet()) {
            System.out.println("key:"+stringUserEntry.getKey()+"\tvalue:"+stringUserEntry.getValue().toString());
        }


        //迭代器
        Iterator<String> keys = userMap.keySet().iterator();
        while (keys.hasNext()){
            User entry = userMap.get(keys.next());
            System.out.println("keys:"+keys.toString()+"\tvalues:"+entry.toString());
        }


    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    class User{
        String id;
        String name;
    }


}

```


之前写了好几个类似的for循环和迭代器，但是由于只是打印输出语句，然后当你写while（iterator.hasNext()）的时候他就会提示你转为for循环，所以又删除了。

list，set之类的迭代器也是一样的用法，内容基本也就是这样，万变不离其宗，大概就这样吧。
