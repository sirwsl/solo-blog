title: java常用注解使用  二（Spring系列）
date: '2020-09-28 00:12:03'
updated: '2020-09-28 08:36:30'
tags: [JAVA, spring]
permalink: /articles/2020/09/28/1601223123315.html
---
### @Component与@Repository

@Component就是跟<bean>一样，可以托管到Spring容器进行管理,@Component是通用注解，@Service, @Controller, @Repository三个注解是这个注解的拓展，并且具有了特定的功能
@Repository 会被作为持久层操作（数据库）的bean来使用
**PS :**

建议使用@Component不建议使用@Repository,虽然作用相差不大，但是代码可读性增强



**PS2：**
@Repository注解：用于标注数据访问组件，即DAO组件
@Service注解：用于标注业务层组件
@Controller注解：用于标注控制层组件（如stru ts中的action）
@Component注解：泛指组件，当组件不好归类的时候，我们可以使用这个注解进行标注。**

### @RequestMapping

value：用于指定请求的 URL。它和 path 属性的作用是一样的。
method：用于指定请求的方式。
params：用于指定限制请求参数的条件。要求请求参数的 key 和 value 必须和 配置的一模一样。


### @Transactional

在需要事务管理的地方加@Transactional 注解。@Transactional 注解可以被应用于接口定义和接口方法、类定义和类的public 方法上。

PS：@Transactional 注解只能应用到 public 可见度的方法上， @Transactional 注解可以作用于接口、接口方法、类以及类方法上，但是 Spring 建议不要在接口或者接口方法上使用该注解，因为这只有在使用基于接口的代理时它才会生效

**PS：**注解详情[https://blog.csdn.net/javaxuexilu/article/details/100738686](https://blog.csdn.net/javaxuexilu/article/details/100738686 "点击跳转")

### @Resource

@Resource和@Autowired注解都是用来实现依赖注入的。只是@AutoWried按by type自动注入，而@Resource默认按byName自动注入。
两个属性：name和type
如果使用name属性，则使用byName的自动注入策略，如果使用type属性则使用byType的自动注入策略
如果有多个相同对象时候需要使用@Qualifier("")
eg：

```java
@Resource
@Qualifier("defaultFile")
private File file1;

@Resource
@Qualifier("namedFile")
private File file2;
```



### @RestController 与 @ResponseBody

@RestController=@Controller+@Responsebody
@RestController:返回的直接是字符串


### @Valid

**eg:**

```java
public Object object
```

校验数据，如果数据异常则会统一抛出异常

```
@Null
限制只能为null

@NotNull
限制必须不为null

@AssertFalse
限制必须为false

@AssertTrue
限制必须为true

@DecimalMax(value)
限制必须为一个不大于指定值的数字

@DecimalMin(value)
限制必须为一个不小于指定值的数字

@Digits(integer,fraction)
限制必须为一个小数，且整数部分的位数不能超过integer，小数部分的位数不能超过fraction

@Future
限制必须是一个将来的日期

@Max(value)
限制必须为一个不大于指定值的数字

@Min(value)
限制必须为一个不小于指定值的数字

@Past
限制必须是一个过去的日期

@Pattern(value)
限制必须符合指定的正则表达式

@Size(max,min)
限制字符长度必须在min到max之间

@Past
验证注解的元素值（日期类型）比当前时间早

@NotEmpty
验证注解的元素值不为null且不为空（字符串长度不为0、集合大小不为0）

@NotBlank
验证注解的元素值不为空（不为null、去除首位空格后长度为0），不同于@NotEmpty，@NotBlank只应用于字符串且在比较时会去除字符串的空格

@Email
验证注解的元素值是Email，也可以通过正则表达式和flag指定自定义的email格式
```


### @PathVariable("xxx")

@PathVariable("xxx") 与 @RequestMapping()
通过 @PathVariable 可以将URL中占位符参数{xxx}绑定到处理器类的方法形参中@PathVariable(“xxx“)

```
@RequestMapping(value=”user/{id}/{name}”)
#请求路径：http://localhost:8080/hello/show5/1/james
```


### @RequestBody @RequestHeader("")与@RequestParam("")

一个参数上加上该注解，spring就会将request body中的json/xml对象解析成该参数类型的Javabean对象
@RequestBody接收数据时，**前端不能使用GET方式提交数据，而是用POST方式进行提交**
@RequestBody与@RequestParam()可以同时使用，@RequestBody最多只能有一个，而@RequestParam()可以有多个。

**@RequestParam的使用方式类似,使用注解把请求路径指定的参数提取出来作为实参注入形参中**
value  对应头文件中的键
defaultValue 该参数的默认值
required  是否必须

```java
public String accept(@RequestHeader(value = "Accept", required = true,
                      defaultValue = "MyAccept") String accept,Model model){}
```

### @Deprecated

若某类或某方法加上该注解之后，**表示此方法或类不再建议使用**，调用时也会出现删除线，但并不代表不能用，只是说，不推荐使用，因为还有更好的方法可以调用
since: 指定已注解的API元素已被弃用的版本。
forRemoval: 表示在将来的既定版本中会被删除，应该迁移 API

```java
@Deprecated(since = "1.2", forRemoval = true)
```
