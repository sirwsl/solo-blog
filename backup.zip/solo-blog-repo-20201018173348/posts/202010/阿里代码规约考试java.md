title: 阿里代码规约考试（java）
date: '2020-10-11 14:09:02'
updated: '2020-10-11 14:09:02'
tags: [随笔记录]
permalink: /articles/2020/10/11/1602396542246.html
---
![](https://b3logfile.com/bing/20191229.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

嗯，今天我们就来说说阿里规约考试，全程阿里云Apsara Couder基础技能认证--阿里巴巴编码规范（java），至于为什么要考这个东西呢，其实之前在idea上也安装过阿里规约插件，但是自己没怎么使用。而现在大四实习，来了我们当地的一家公司，在入职几天后，公司一直让看代码规范文档，之后让通过阿里代码规约考试，自己在看了几天，然后归纳了相关的一些阿里题库，全部记下来，考个90多应该是没什么问题的。

阿里代码规约考试题库在此，需要的自己下载，喜欢的关注一下呗

[阿里规约考试.zip](https://b3logfile.com/file/2020/10/阿里规约考试-5e9eda0f.zip)

[阿里规约考试.zip](https://b3logfile.com/file/2020/10/阿里规约考试-5e9eda0f.zip)

[阿里规约考试.zip](https://b3logfile.com/file/2020/10/阿里规约考试-5e9eda0f.zip)


下面就是题库，本人靠这个东西已经通过，emmmmmm

![阿里规约考试0.png](https://b3logfile.com/file/2020/10/阿里规约考试0-9ca0bf30.png)

![阿里规约考试1.png](https://b3logfile.com/file/2020/10/阿里规约考试1-b0108e19.png)
