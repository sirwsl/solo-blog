title: nginx反向代理CSS、JS无法加载
date: '2020-07-08 14:47:08'
updated: '2020-07-08 14:50:04'
tags: [bug]
permalink: /articles/2020/07/08/1594190828699.html
---
![](https://b3logfile.com/bing/20200301.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

虽然期末要考试了，昨天晚上看见solo更新了，然后今天准备更新一下我的solo，结果出现了个意外，因为原来是挂在8080端口，现在准备换一下，结果出错了。具体就是：

通过Nginx反向代理solo 的时候，**通过域名访问出现了网页无法加载CSS、JS等相关的资源，但是页面能够访问，只是页面所有内容全部排版错乱没有样式了**。但是能够通过IP+port进行访问。

按F12出现的错误

![image.png](https://b3logfile.com/file/2020/07/image-af4d709d.png)

因此可以确定一点就是solo的镜像正常。然后开始各种排查最终的原因是：

**在docker发布镜像的时候少加了s（https我写成了http）**

![image.png](https://b3logfile.com/file/2020/07/image-cd861392.png)

**服务器因为在访问的时候是通过https访问的，然后http，就会报错，所以，需要换成https，就可以了。**

刚开始找的时候大多数的解决方式如下（我的没有用、大家没有解决的也可以试试）：

![无效.png](https://b3logfile.com/file/2020/07/无效-2fde8920.png)
