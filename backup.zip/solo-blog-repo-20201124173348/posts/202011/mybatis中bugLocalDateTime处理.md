title: mybatis中bug——LocalDateTime处理
date: '2020-11-15 17:59:32'
updated: '2020-11-15 17:59:32'
tags: [bug, mybatis]
permalink: /articles/2020/11/15/1605434372351.html
---
![](https://b3logfile.com/bing/20190812.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 背景

今天在写rabbbitMQ的时候出现了一个关于时间序列化的问题，我也是很难受，和mq斗争了三天了，今天总算基本的完成了，之后直接用就好。以后还是要多加学习，毕竟菜是原罪。错误如下

## Bug：

```java
2020-11-15 16:26:55[ WARN ]Execution of Rabbit message listener failed.

org.springframework.amqp.rabbit.support.ListenerExecutionFailedException: Listener threw exception

Caused by: org.springframework.amqp.support.converter.MessageConversionException: Failed to convert Message content

Caused by: com.fasterxml.jackson.databind.exc.InvalidDefinitionException: Cannot construct instance of `java.time.LocalDateTime` (no Creators, like default constructor, exist): cannot deserialize from Object value (no delegate- or property-based Creator)
 at 
[Source: (String)"{"id":43,"title":"123庆国中秋","detail":"2020年1月1日","type":0,"adminId":1,"realFlag":null,"creatTime":{"year":2020,"month":"NOVEMBER","nano":625000000,"monthValue":11,"dayOfMonth":15,"hour":16,"minute":26,"second":54,"dayOfWeek":"SUNDAY","dayOfYear":320,"chronology":{"calendarType":"iso8601","id":"ISO"}},"updateTime":"2020-11-15 16:26:54","delFlag":null}"; line: 1, column: 99] (through reference chain: com.wsl.shoppingKill.domain.SubscriptionHistory["creatTime"])
```

![image.png](https://b3logfile.com/file/2020/11/image-0f8edb88.png)![image.png](https://b3logfile.com/file/2020/11/image-c05d134f.png)![image.png](https://b3logfile.com/file/2020/11/image-e6c95090.png)

![image.png](https://b3logfile.com/file/2020/11/image-a0ce348a.png)

## 大概原因：

按照我自己的理解，可能存在错误，但是解决方法是没问题的，大概就是我们在建立类的时候引入了Serializable

大概像这样：

![image.png](https://b3logfile.com/file/2020/11/image-3bbbbc2d.png)

因为当时为了方便序列化所以直接就继承Serializable，然后对于LocalDateTime，我也是醉了，在mabatis序列化时候需要添加JSONFormat注解。而今天这个错是在rabbitMq序列化时候那报错说没得无参构造，但是我明明打了注解，继续往下看就是LocalDateTime返序列化出现问题，所以只好又加两个注解，如下图。

![image.png](https://b3logfile.com/file/2020/11/image-1cb6c871.png)

## 解决方式

在localDateTime属性上添加注解：

```java
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
```
