title: idea中的VM参数参数调优
date: '2020-10-11 14:29:14'
updated: '2020-10-11 14:29:14'
tags: [随笔记录]
permalink: /articles/2020/10/11/1602397754100.html
---
![](https://b3logfile.com/bing/20190825.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

以下是自己使用的ideaVM参数调优，记录以下，以后直接复制使用，有需要的自己copy

```bash
-Xms2g
-Xmx4g
-Xmn576m
-XX:+AlwaysPreTouch
-XX:MetaspaceSize=256m 
-XX:MaxMetaspaceSize=768m
-XX:ReservedCodeCacheSize=240m

-server
-Xms1024m
-Xmx2048m
-XX:MaxPermSize=1024m
-XX:ReservedCodeCacheSize=512m
-XX:+UseConcMarkSweepGC
-XX:+UseCodeCacheFlushing
-XX:SoftRefLRUPolicyMSPerMB=50


-ea
-Dsun.io.useCanonCaches=false
-Dsun.awt.keepWorkingSetOnMinimize=true
-Djava.net.preferIPv4Stack=true

-Dfile.encoding=UTF-8
-XX:CICompilerCount=2
-Dsun.io.useCanonPrefixCache=false
-Djdk.http.auth.tunneling.disabledSchemes=""
-Djsse.enablesSNIExtension=false
-XX:+HeapDumpOnOutOfMemoryError
-XX:-OmitStackTraceInFastThrow
-Djdk.attach.allowAttachSelf=true
-Dkotlinx.coroutines.debug=off
-Djdk.module.illegalAccess.silent=true
-javaagent:C:\Users\Public\.jetbrains\jetbrains-agent-v3.2.0.0f1f.69e=6e68f9eb,LFq51qqupnaiTNn39w6zATiOTxZI2JYuRJEBlzmUDv4zeeNlXhMgJZVb0q5QkLr+CIUrSuNB7ucifrGXawLB4qswPOXYG7+ItDNUR/9UkLTUWlnHLX07hnR1USOrWIjTmbytcIKEdaI6x0RskyotuItj84xxoSBP/iRBW2EHpOc

```
