title: 浅谈Restful
date: '2020-05-25 16:53:40'
updated: '2020-05-25 17:14:31'
tags: [JAVA, 设计模式, Restful]
permalink: /articles/2020/05/25/1590396820627.html
---
在开始写之前，个人认为在编程中，对于java来说是一切事物皆对象，在Restful架构风格中核心思想是资源，可以含糊的说为“一切链接皆资源”，接下来说说restful

## 一、restful是什么？

Rest与Restful 简单理解为同一回事，基于REST构建的API就是Restful风格，REST 就是一种设计 API 的模式。最常用的数据格式是 JSON。Rrestful是什么一种分布式系统应用层解决方案、能够实现client与server的解耦。Restful是一种面向资源的一种如那件架构风格，他可以降低开发的复杂性，提高系统的可伸缩性。

restful面向资源接口设计以及操作抽象简化了开发者的不良设计，同时极大限度利用资源。

## 二、设计规范：

**协议**：使用https
**域名**：尽量将api部署在专有域名下
**版本**：放在url或者是header中
**路径**：每一个地址都是表示一种资源，不能有动词，只有名次，一般来说API中名词为复数
**过滤信息**： ？Limit=10 ？Offset10  ？Page=1 ？Sortby=name（排序）

## 三、请求方式：

面向资源的接口设计，抽象操作作为基础的CURD

| Method | CRUD | Detail |
| --- | --- | --- |
| GET | READ | 从服务器取出资源（一项或多项） |
| POST | CREATE | 在服务器新建一个资源 |
| PUT | UPDATE | 在服务器更新资源（客户端提供改变后的完整资源） |
| PATCH | UPDATE | 在服务器更新资源（客户端提供改变的属性) |
| DELETE | DELETE | 从服务器删除资源 |
| HEAD |   | 获取资源的元数据 |
| OPTIONS |   | 获取信息，关于资源的哪些属性是客户端可以改变的 |

## 四、Spring中的应用：

```
//@RequestMapping(value = "/{id}", method = RequestMethod.GET)
@GetMapping(value="/{id}") 
public String toUpdate(@PathVariable("id") Integer id, Student stu) {}

```

| Method | or1 | or2 |
| --- | --- | --- |
| GET | @GetMapping(） | @RequestMapping(method = RequestMethod.GET) |
| POST | @PostMapping() | @RequestMapping(method = RequestMethod.POST) |
| PUT | @PutMapping() | @RequestMapping(method = RequestMethod.PUT） |
| PATCH | @DeleteMapping() | @RequestMapping(method = RequestMethod.PATCH) |
| DELETE | @DeleteMapping() | @RequestMapping(method = RequestMethod.DELETE) |
| HEAD |   | @RequestMapping(method = RequestMethod.HEAD) |
| OPTIONS |   | @RequestMapping(method = RequestMethod.OPTIONS) |

## 五、返回结果：

| 方式 | 路径 | 说明 |
| --- | --- | --- |
| Get | /demos | 返回资源对象列表 |
| Get | /demos/1 | 返回单个资源对象 |
| Post | /demos | 返回新生成资源对象 |
| Put | /demos/1 | 返回完整的资源对象 |
| Patch | /demos/1 | 返回修改的属性 |
| Delete | /demos/1 | 返回空的相应体 |

## 六、AJAX请求

```js
$.ajax( {  
           type : "DELETE",  
           url : "/test/demo/" + id,  
           dataType : "json",  
           success : function(data) {  
               alert(data);  
               location.href = "/test/demo/1";  
           }  
      });

```

## PS：

1. SOAP安全性高于REST，但是REST效率与易用性高于SCOP
2. Post是不幂等方法，get是幂等方法。幂等性：发送100次与发送一次的引起的边界效应一致也就是结果一致
3. Get、Head、Options安全方法，只是获取数据，不具有边界效应

❤️ **给梦想一点时间，每天进步一点点**❤️
