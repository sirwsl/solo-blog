title: 我在 GitHub 上的开源项目
date: '2020-05-19 11:51:30'
updated: '2020-05-19 11:51:30'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [Spring](https://github.com/sirwsl/Spring) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/sirwsl/Spring/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/sirwsl/Spring/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/sirwsl/Spring/network/members "分叉数")</span>

这是一个spring、SSM、SSH、SpringBoot入门项目，适合对Spring有兴趣的人参考（PS：This is a spring, SSM, SSH, SpringBoot entry project, suitable for those interested in Spring reference）



---

### 2. [community](https://github.com/sirwsl/community) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/sirwsl/community/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/sirwsl/community/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/sirwsl/community/network/members "分叉数")</span>

高校社团管理系统，基于springboot开发。采用restful风格进行。多级权限控制，融入短信接口。主要功能有会员管理、活动管理、场地管理、会议管理、社团管理、消息通知、文件下发等模块（Community management system, based on springboot development. In restful style. Multi level authority control, integrated into SMS interface. The main functions are member management, activity management, venue management, meeting management, community management, message notification, document distribution and other modules）



---

### 3. [Homework](https://github.com/sirwsl/Homework) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/sirwsl/Homework/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/sirwsl/Homework/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/sirwsl/Homework/network/members "分叉数")</span>

This is a job submission system built using servlet + mysql(PS:这是一个使用 servlet+mysql构建的作业提交系统)



---

### 4. [solo-blog](https://github.com/sirwsl/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/sirwsl/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/sirwsl/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/sirwsl/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.wslhome.top`](https://www.wslhome.top "项目主页")</span>

✍️ 给梦想一点时间,让它一步步成长 - 有事做、有人爱、有所期待



---

### 5. [myself](https://github.com/sirwsl/myself) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/sirwsl/myself/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/sirwsl/myself/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/sirwsl/myself/network/members "分叉数")</span>

我的个人简历

