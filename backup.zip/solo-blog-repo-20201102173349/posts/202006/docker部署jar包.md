title: docker部署jar包
date: '2020-06-07 22:47:57'
updated: '2020-06-08 07:25:04'
tags: [docker]
permalink: /articles/2020/06/07/1591541277838.html
---
### 背景：

因为在solo主页添加个人简历模块，做了一份个人简历，然后加在solo外链上，但是由于是GitHub静态部署的，然后访问时候加载时候特别受不了。由于solo还会存在版本更新，改代码嫌太麻烦了。

然后就想自己不是买了服务器，为什么不挂载在服务器上。想了想开干。

### 将项目打包为jar包。具体步骤百度.

（我是将项目导入springboot后maven打包，因为这样省去我大把时间，我就是一个只要结果和效率的人）

上传jar包到服务器指定目录。xshell中使用rz -y

### 目录中创建Dockerfile文件。

```
vi Dockerfile
```

### 输入下面内容：

```
FROM java:8
MAINTAINER wsl
ADD demo-0.0.1-SNAPSHOT.jar demo.jar
EXPOSE 8080
ENTRYPOINT ["java","-jar","demo.jar"]
```

分别对应：docker jdk image    作者   jar包与重命名jar包    运行端口     执行命令

### 构建domo镜像：

```
docker build -t myself/demo .
```

注意后面的小数点 .标识当前目录下 。 myself/demo镜像名称。这个速度十分缓慢，耐心等待。

### 运行镜像：

```
 docker run -d --restart=always --name demo -p 888:888  myself/demo 
```

用docker ps查看正在运行的容器，看看是否成功。

失败用docker logs myself/demo查看日志。

提前在防火墙中开放暴露端口。
