title: Redis搭建与基础知识
date: '2020-06-12 14:54:17'
updated: '2020-06-17 14:02:07'
tags: [redis]
permalink: /articles/2020/06/12/1591944857524.html
---
![](https://b3logfile.com/bing/20200529.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 一、NoSQL概述

**NoSQL（Not Only SQL）：**

非关系型数据库，适用于高并发的读写发生时,实现海量数据的高效率的存储与访问，从而实现一高可用性与可扩展性。

**NoSQL主流产品：**

mongoDB、Redis、Cassandra、CouchDB...

**NoSQL四大分类：**

键值对存储、列存储、文档存储（mongoDB）、图形数据库

**NoSQL特点：**

易扩展、灵活的数据模型、大数据量高性能、高可用

### 二、Redis概述

**Redis：**

是一款开源的、采用C语言开发、采用键值对的形式、具有高性能的数据库。

**数据类型：（具体内容参见另一篇博客：[https://www.wslhome.top/articles/2020/06/16/1592312645001.html](https://www.wslhome.top/articles/2020/06/16/1592312645001.html "为什么不点我看看呢？？？")）**

字符串类型、散列类型、列表类型、集合类型、有序集合类型

**Redis应用场景：**

缓存、任务队列、分布式集群架构中的session分离、网站访问统计、应用排行榜、数据过期处理

### 三、Redis安装

1. **创建文件夹、并进入文件夹下**

   ```
   mkdir /home/redis
   cd /home/redis
   ```
2. **下载redis**

   ```
   wget  http://download.redis.io/releases/redis-5.0.4.tar.gz
   ```
3. **解压redis**

   ```
   tar -xvf redis-5.0.4.tar.gz
   ```
4. **安装编译环境GCC**

   ```
   yum install gcc-c++
   ```
5. **进入redis5.0.4目录**

   ```
   cd redis-5.0.4/
   ```
6. **编译redis**

   ```
   make
   ```
7. **安装redis**：PREFIX参数指定redis的安装目录

   ```
   make install PREFIX=/usr/local/redis

   ```
8. **修改配置：**

   ```

   cd /usr/local/redis  #进入目录

   cp /home/redis/redis-5.0.4/redis.conf single.conf #拷贝文件

   ```


   **(1)打开single.conf文件**

```
vim single.conf
```

**(2)修改配置：**

```
#bind 127.0.0.1    #本机访问注释掉
 port 6379         #端口号，可以修改
protected-mode no  #关闭保护
daemonize yes      #开启后台启动（不开启运行后就不能做其余操作）
#保存退出 按esc输入:wq
```

**（3）设置开机自启动**

```
./install_server.sh       #redis 安装目录中有util文件夹，文件夹中有install.sh文件， 进入目录执行，一值回车
mv /etc/init.d/redis_6379 /etc/init.d/redisd   #可以看见Copied /tmp/6379.conf=>/etc/init.d/redis_6379
chkconfig --add redisd   #升级为系统服务
systemctl start redisd   #用linux系统命令systemctl启动redis服务
systemctl daemon-reload  #刷新配置
```

9. **启动服务**
   ```
   cd /usr/local/redis/
   redis-server redis.conf  #开启服务端
   redis-cli -p 6379  #如果没有更改端口直接 redis-cli
   ```

**10.查看redis是否启动**

```
ps aux|grep redis

```

**11.测试**

```
./redis-cli -h 127.0.0.1 -p 6379 #进入redis安装目录
set test 123
get test

```

### 四、Jedis连接

jedis是redis官网首选的java语言开发包 github：github.com/xetorthio/jedis

```java
package jedis;
#导入jedis-2.9.0.jar与commons-pool2.jar


import org.junit.Test;


import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;


public class Demo {
	String host = "192.168.241.128";
	int port = 6379; 
	@Test
	//单例
	public void test1() {
		Jedis jedis = new Jedis(host,port);
		jedis.set("name", "张三");
		String name = jedis.get("name");
		System.out.println(name);
	}

	@Test
	//连接池
	public void test2() {
		//设置连接池
	      JedisPoolConfig config=new JedisPoolConfig();  
	      //设置最大允许连接数  
	      config.setMaxTotal(50);  
	      //设置最大的空闲连接  
	      config.setMaxIdle(10);  
	      //1. 创建Jeids连接池对象  
	      JedisPool jdJedisPool=new JedisPool(config, host, port);

		Jedis jedis = null;
		try {
			jedis = jdJedisPool.getResource();
			jedis.set("name", "李四");
			String name = jedis.get("name");
			System.out.println(name);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(jedis !=null) jedis.close();
			if(jdJedisPool != null) jdJedisPool.close();
		}
	}



}

```

### 五、Redis命令

* **字符串（String）**

```apache
set name test 		 #赋值
get name      		 #取值
getset  name lisi  	 #取值之后赋值
del name    		 #删除
incr num    		 #数值递增一，不存在设置为0在+1
decr num    		 #数值减一，不存在设置为0在-1
incrby num 5 		 #指定增加数值
decrby num 3		 #指定减少数值
append num 1		 #在原有值后面增加字符串
```

* **哈希（hash）**

```
hset test name li age 12  		#增加一组
hmset user name zhangsang password 123  #增加user中的name与password
hget test name  			#获取name
hmget user name age 			#获取user中的name与age
hgetall user 				#获取整个user
hdel test name 				#删除name
hdel user  				#删除整个hash
hincrby user age 5 			#指定某个hash某个属性增加多少值
hexists user name  			#判断属性是否存在
hlen user 	 #获取hash有几个属性
hkeys user	 #获取所有的key
hvals user	 #获取所有的value
```

* **链表（list）**

```
lpush list1  1 2 3 	#添加1 2 3 到list1  左添加
rpush list2 1 2 3 	#添加 1 2 3到list2   右添加
lrange list1 0 -1 	#查看有多少元素  开始元素0  结尾元素为-1
lrange list2 0 2
lpop list1 		#弹出一个队首元素
rpop list2 		#弹出最后一个元素
llen  list1 		#查看有个元素
lpushx list a 		#如果存在在头部插入a，不存在不插入
lpushx list1 a
lrem list1 2 1 		#从头删除2个1
lrem lsit2 -2 1 	#从尾删除2个1
lset list 2 abc 	#在list中的第二个位置插入abc
linsert list2 after abc def   #在list2中的abc之后插入def
linsert list2 before abc def  #在list2中的abc之前插入def
lpoplpush list1 list2 	      #将list1中最后一个元素弹出插入list2队列中

```

* **集合（set）**

```
sadd set1 1 2 3		 #添加1 2 3到set集合
srem  set1 1 2 		 #删除12 
smembers set1 		 #查看set1中的数据
sismember set1 a	 #判断a在不在set中
sdiff set1 set2 	 #set1 set2 的差集运算
sinter set1 set2	 #交集运算
sunion set1 set2 	 #并集运算
scard set1 		 #获取集合数量
srandmember set1	 #随机返回元素
sdiffstore set1 set2 set3  #将set1 与 set2 的差集存储在set3中
sinterstore set1 set2 set3 #将set1 与set2的交集存储在set3
sunionstore set1 set2 set3 #将set1与set2的并集存储在set3中

```

* **有序集合（sorted-set）**

每一个成员都有一个成员有一个分数与之关联，位置有序

```
zadd so 70 zhangsang 80 sili 100 wangwu #添加张三李四王五并与分数关联
zadd so 90 zhangsang     #更新张三分数
zcore so zhansang 	 #获取zhansang分数
zcard so		 #查看多少元素
zrem so sili wangwuq	 #删除sili wangwu
zrange so 0 -1           #查看多少元素
zrange so 0 -1 withscores #显示元素与对应分数
zrevrange so 0 -1         #排名
zremrangebyrank so 0 2    #删除0-2元素
zremrangebyscore so 90 100 #删除分数为90-100的元素
zrangebycore so 0 100      #查重0 - 100
zincrby so 20 zhangsang    #增加李四分数权重
zcount so 80 100           #统计80-100的个数

```

* **通用命令：**

```
keys * 			 #查看所有的keys
keys m?			 #查看以m开头的key
del so user 		 #删除key
exists so		 #查看so是否存在
rename com com1  	 #重命名
expire key seconds	 #设置使用时间
expireat key timestamp   #设置时间戳
ttl key               	 #获取剩余时间 -1不存在 -2过期
pttl key
persist key		 #转化为永久
type so		 	 #获取so的类型
keys u[st]er 	 	 #st任意一个字符[]匹配一个指定符号
```

### **六、高级数据类型：Bitmaps、HyperLogLog、GEO**

* **bitmaps**

采用计算机中最小存储单位bit进行存储。类似以时间换空间。

在使用过程中，如果是连续数且比较大的化，则减去一个属，否则可能造成较为耗时

```
#getbit key offset
#setbit key offset value
setbit num 2 1 
getbit num 2)
#bitop {and/or/not/xor} destkey key1 key2
#对key按位进行交并补非异或的错做，将结果保存到destkey中《and\or\not\xor》
bitop or key key1 key2 key3 #将key123进行异或操作后存入key中
bitcount key #统计key中1的数量：
```

* **HyperLogLog:数据基数统计**

对数据基数进行统计，但是需要注意的是，他只是用于统计，没有具体的数据

```
pfadd key element #添加数据
pfcount key #统计数据
pfmerge destkey sourcekey #数据与合并
```

**PS:**

HyperLogLog核心是基数估算算法，最终结果有误差（0.81%）
存储空间较小（内存12K）
pfadd命令不是一次分配12K，而实基数增大而增大
pfmerge合并后张勇的存储空间未12K，无论之前数据量多大

* **GEO:**

常用于类似坐标操作

```
#添加坐标点
#geoadd key longitude latitude member 
geoadd geos 1 1 a
#获取坐标点：
#geopos key member 
geopos geos a
#计算坐标距离
geodist key member 1 member 2
#获取坐标范围内的数据：
#georadius key logintude latitude radius m\km\ft\mi 
georadius geos 1.5 1.5 90 km
#根据点求范围内数据：
#georadiusbymember key member radius m\km\ft\mi 
georadiusbymember ges 1 1800 km
#获取指定点的hash值
geohash key member 
```

### 七、Redis特性与持久redis

* **Radis是个多数据库的，最多支持16个数据库，通过 select num进行选择**

```
select 1   #选择数据库
move so 1  #将so移动到1号数据库

ping       #测试服务器是否联通
quit       #退出
dbsize     #看数据库有多少key
flushall   #清除所有库
flushdb    #清除所在库的数据
```

* **支持事务：multi(开启事务) exec（提交事务） discard（回滚事务）**
* **持久化：RDB与AOF**

RDB；默认方式，在指定时间内的将内存中的数据写入磁盘一次

AOP：以日志记录，每次启动都会读取进行构建

可以不进行持久化处理（只是使用缓存）也可以同时使用RDB与AOF

具体参见另一篇博客：[https://www.wslhome.top/articles/2020/06/16/1592312734423.html](https://www.wslhome.top/articles/2020/06/16/1592312734423.html "点我啊")
